#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Custom Data Structure: Linked List Node
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Red-Black Tree Node Structure
typedef struct RBNode {
    int data;
    enum { RED, BLACK } color;
    struct RBNode *left, *right, *parent;
} RBNode;

// Insertion in Custom Data Structure: Linked List
Node* insertCustom(Node* head, int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->next = head;
    return newNode;
}

// Searching in Custom Data Structure: Linked List
int searchCustom(Node* head, int value) {
    Node* curr = head;
    while (curr != NULL) {
        if (curr->data == value) {
            return 1; // Found
        }
        curr = curr->next;
    }
    return 0; // Not found
}

// Insertion in Red-Black Tree
// Insertion in Red-Black Tree
RBNode* insertRBTree(RBNode* root, RBNode* newNode) {
    // Insertion similar to Binary Search Tree insertion
    if (root == NULL) {
        return newNode;
    }

    if (newNode->data < root->data) {
        root->left = insertRBTree(root->left, newNode);
        root->left->parent = root;
    } else if (newNode->data > root->data) {
        root->right = insertRBTree(root->right, newNode);
        root->right->parent = root;
    } else {
        // Duplicates not allowed
        free(newNode);
        return root;
    }

    // Balancing logic
    if (root->left != NULL && root->left->color == RED && root->left->left != NULL && root->left->left->color == RED) {
        // Left-Left case
        RBNode* y = root->left;
        root->left = y->right;
        if (root->left != NULL) {
            root->left->parent = root;
        }
        y->right = root;
        y->parent = root->parent;
        root->parent = y;
        y->color = BLACK;
        return y;
    } else if (root->right != NULL && root->right->color == RED && root->right->right != NULL && root->right->right->color == RED) {
        // Right-Right case
        RBNode* y = root->right;
        root->right = y->left;
        if (root->right != NULL) {
            root->right->parent = root;
        }
        y->left = root;
        y->parent = root->parent;
        root->parent = y;
        y->color = BLACK;
        return y;
    } else if (root->left != NULL && root->left->color == RED && root->right != NULL && root->right->color == RED) {
        // Left-Right case
        root->left = insertRBTree(root->left, root->left->right);
        root->left->parent = root;
        return root;
    } else if (root->right != NULL && root->right->color == RED && root->left != NULL && root->left->color == RED) {
        // Right-Left case
        root->right = insertRBTree(root->right, root->right->left);
        root->right->parent = root;
        return root;
    }

    return root;
}


// Searching in Red-Black Tree
int searchRBTree(RBNode* root, int value) {
    RBNode* current = root;
    while (current != NULL) {
        if (value == current->data) {
            return 1; // Found
        } else if (value < current->data) {
            current = current->left;
        } else {
            current = current->right;
        }
    }
    return 0; // Not found
}
//This function performs a standard binary search in the Red-Black Tree to find the node with the given value. If the value is found in the tree, it returns 1 (for "Found"), otherwise, it returns 0 (for "Not found"). You can use this function to measure the time taken for searching in the Red-Black Tree along with the custom data structure's searching time.






// Balance fixing after Red-Black Tree insertion
// Balance fixing after Red-Black Tree insertion
void fixRBTreeAfterInsertion(RBNode* newNode) {
    while (newNode != NULL && newNode->color == RED && newNode->parent != NULL && newNode->parent->color == RED) {
        RBNode* grandparent = newNode->parent->parent;

        // Case 1: Parent is the left child of grandparent
        if (newNode->parent == grandparent->left) {
            RBNode* uncle = grandparent->right;

            // Case 1.1: Uncle is also red, recoloring
            if (uncle != NULL && uncle->color == RED) {
                newNode->parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                newNode = grandparent;
            } else {
                // Case 1.2: Uncle is black or NULL, rotation required
                if (newNode == newNode->parent->right) {
                    newNode = newNode->parent;
                    // Left rotation
                    // ...
                }

                newNode->parent->color = BLACK;
                grandparent->color = RED;
                // Right rotation
                // ...
            }
        } else {
            // Case 2: Parent is the right child of grandparent (symmetric to case 1)
            // ...
        }
    }

    // Ensure the root is black
    if (newNode != NULL && newNode->parent == NULL) {
        newNode->color = BLACK;
    }
}
void freeRBTree(RBNode* root) {
    if (root == NULL) {
        return;
    }

    freeRBTree(root->left);
    freeRBTree(root->right);
    free(root);
}

int main() {
    clock_t start, end;
    double custom_insertion_time, custom_search_time;
    double rb_tree_insertion_time, rb_tree_search_time;

    int numKeys;
    printf("Enter the number of keys: ");
    scanf("%d", &numKeys);

    // Construct and initialize your custom data structure (Linked List)
    Node* customHead = NULL;

    // Construct and initialize Red-Black Tree
    RBNode* rbRoot = NULL;

    // Perform insertion in custom data structure
    start = clock();
    for (int i = 0; i < numKeys; i++) {
        customHead = insertCustom(customHead, i);
    }
    end = clock();
    custom_insertion_time = ((double)(end - start)) / CLOCKS_PER_SEC;

    // Perform insertion in Red-Black Tree
    start = clock();
    for (int i = 0; i < numKeys; i++) {
        RBNode* newNode = (RBNode*)malloc(sizeof(RBNode));
        newNode->data = i;
        newNode->color = RED; // New nodes are always red
        newNode->left = newNode->right = newNode->parent = NULL;
        
        rbRoot = insertRBTree(rbRoot, newNode);
        fixRBTreeAfterInsertion(newNode);
    }
    end = clock();
    rb_tree_insertion_time = ((double)(end - start)) / CLOCKS_PER_SEC;

    // Perform searching in custom data structure
    start = clock();
    for (int i = 0; i < numKeys; i++) {
        int found = searchCustom(customHead, i);
    }
    end = clock();
    custom_search_time = ((double)(end - start)) / CLOCKS_PER_SEC;

    // Perform searching in Red-Black Tree
    start = clock();
    for (int i = 0; i < numKeys; i++) {
        int found = searchRBTree(rbRoot, i);
    }
    end = clock();
    rb_tree_search_time = ((double)(end - start)) / CLOCKS_PER_SEC;

    // Output time measurements
    printf("Custom Data Structure - Insertion Time: %f seconds\n", custom_insertion_time);
    printf("Red-Black Tree - Insertion Time: %f seconds\n", rb_tree_insertion_time);
    printf("Custom Data Structure - Search Time: %f seconds\n", custom_search_time);
    printf("Red-Black Tree - Search Time: %f seconds\n", rb_tree_search_time);

    // Continue with measurement for deletion operation and comparison

    // Free memory used by custom data structure (Linked List)
    while (customHead != NULL) {
        Node* temp = customHead;
        customHead = customHead->next;
        free(temp);
    }

    // Free memory used by Red-Black Tree (you need to implement this)

    return 0;
}

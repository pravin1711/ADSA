#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

enum Color { RED, BLACK };

struct RedBlackTreeNode {
    int data;
    enum Color color;
    struct RedBlackTreeNode *left;
    struct RedBlackTreeNode *right;
    struct RedBlackTreeNode *parent;
};

struct TreeNode {
    int data;
    struct TreeNode *left;
    struct TreeNode *right;
};

struct GraphNode {
    int vertex;
    int weight;
    struct GraphNode *next;
};

struct Graph {
    int numVertices;
    struct GraphNode **adjLists;
};


struct RedBlackTreeNode *createRedBlackTreeNode(int data) {
    struct RedBlackTreeNode *newNode = (struct RedBlackTreeNode *)malloc(sizeof(struct RedBlackTreeNode));
    newNode->data = data;
    newNode->color = RED; // Default color for simplicity
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->parent = NULL;
    return newNode;
}

// Rotate functions
void leftRotate(struct RedBlackTreeNode **root, struct RedBlackTreeNode *x) {
    struct RedBlackTreeNode *y = x->right;
    x->right = y->left;
    if (y->left != NULL) y->left->parent = x;
    y->parent = x->parent;
    if (x->parent == NULL) *root = y;
    else if (x == x->parent->left) x->parent->left = y;
    else x->parent->right = y;
    y->left = x;
    x->parent = y;
}

void rightRotate(struct RedBlackTreeNode **root, struct RedBlackTreeNode *y) {
    struct RedBlackTreeNode *x = y->left;
    y->left = x->right;
    if (x->right != NULL) x->right->parent = y;
    x->parent = y->parent;
    if (y->parent == NULL) *root = x;
    else if (y == y->parent->left) y->parent->left = x;
    else y->parent->right = x;
    x->right = y;
    y->parent = x;
}

void fixViolation(struct RedBlackTreeNode **root, struct RedBlackTreeNode *z) {
    while (z->parent != NULL && z->parent->color == RED) {
        if (z->parent == z->parent->parent->left) {
            struct RedBlackTreeNode *y = z->parent->parent->right;
            if (y != NULL && y->color == RED) {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->right) {
                    z = z->parent;
                    leftRotate(root, z);
                }
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                rightRotate(root, z->parent->parent);
            }
        } else {
            struct RedBlackTreeNode *y = z->parent->parent->left;
            if (y != NULL && y->color == RED) {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->left) {
                    z = z->parent;
                    rightRotate(root, z);
                }
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                leftRotate(root, z->parent->parent);
            }
        }
    }
    (*root)->color = BLACK;
}

void insert(struct RedBlackTreeNode **root, int data) {
    struct RedBlackTreeNode *z = createRedBlackTreeNode(data);
    struct RedBlackTreeNode *y = NULL;
    struct RedBlackTreeNode *x = *root;

    while (x != NULL) {
        y = x;
        if (z->data < x->data) x = x->left;
        else x = x->right;
    }

    z->parent = y;
    if (y == NULL) *root = z;
    else if (z->data < y->data) y->left = z;
    else y->right = z;

    fixViolation(root, z);
}


void inOrderTraversal(struct RedBlackTreeNode *root) {
    if (root != NULL) {
        inOrderTraversal(root->left);
        printf("%d ", root->data);
        inOrderTraversal(root->right);
    }
}

struct TreeNode *convertToBinarySearchTree(struct RedBlackTreeNode *root) {
    if (root == NULL) {
        return NULL;
    }

    struct TreeNode *newNode = (struct TreeNode *)malloc(sizeof(struct TreeNode));
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->data = root->data;

    newNode->left = convertToBinarySearchTree(root->left);
    newNode->right = convertToBinarySearchTree(root->right);

    return newNode;
}

void addEdge(struct GraphNode **adjList, int vertex, int weight) {
    struct GraphNode *newNode = (struct GraphNode *)malloc(sizeof(struct GraphNode));
    newNode->vertex = vertex;
    newNode->weight = weight;
    newNode->next = *adjList;
    *adjList = newNode;
}

void convertTreeToGraph(struct TreeNode *root, struct GraphNode **adjLists) {
    if (root == NULL)
        return;

    if (root->left != NULL)
        addEdge(&adjLists[root->data - 1], root->left->data - 1, abs(root->data - root->left->data));

    if (root->right != NULL)
        addEdge(&adjLists[root->data - 1], root->right->data - 1, abs(root->data - root->right->data));

    // Corrected: Use the vertex - 1 as index for adjacent vertices
    if (root->left != NULL)
        addEdge(&adjLists[root->left->data - 1], root->data - 1, abs(root->data - root->left->data));

    if (root->right != NULL)
        addEdge(&adjLists[root->right->data - 1], root->data - 1, abs(root->data - root->right->data));

    convertTreeToGraph(root->left, adjLists);
    convertTreeToGraph(root->right, adjLists);
}

struct Graph *createGraph(int numVertices) {
    struct Graph *graph = (struct Graph *)malloc(sizeof(struct Graph));
    graph->numVertices = numVertices;
    graph->adjLists = (struct GraphNode **)malloc(numVertices * sizeof(struct GraphNode *));
    for (int i = 0; i < numVertices; ++i)
        graph->adjLists[i] = NULL;
    return graph;
}

void dijkstra(struct Graph *graph, int source) {
    int numVertices = graph->numVertices;
    long long int distance[numVertices];
    int visited[numVertices];

    for (int i = 0; i < numVertices; ++i) {
        distance[i] = LLONG_MAX; // Initialize distances to infinity
        visited[i] = 0;
    }

    distance[source] = 0; // Distance from source to itself is 0

    for (int count = 0; count < numVertices - 1; ++count) {
        int u = -1;
        for (int v = 0; v < numVertices; ++v) {
            if (!visited[v] && (u == -1 || distance[v] < distance[u])) {
                u = v;
            }
        }

        visited[u] = 1;

        struct GraphNode *current = graph->adjLists[u];
        while (current != NULL) {
            int v = current->vertex;
            int weight = current->weight;

            if (!visited[v] && distance[u] != LLONG_MAX && distance[u] + weight < distance[v]) {
                distance[v] = distance[u] + weight;
            }

            current = current->next;
        }
    }

    printf("Shortest paths from source vertex %d:\n", source);
    for (int i = 0; i < numVertices; ++i) {
        if (distance[i] == LLONG_MAX) {
            printf("Vertex %d: Distance = INF\n", i);
        } else {
            printf("Vertex %d: Distance = %lld\n", i, distance[i]);
        }
    }
}

int main() {
    struct RedBlackTreeNode *root = NULL;

    insert(&root, 8);
    insert(&root, 9);
    insert(&root, 6);
    insert(&root, 10);
    insert(&root, 11);
    insert(&root, 5);
    insert(&root, 7);

    printf("In-Order Traversal of Red-Black Tree:\n");
    inOrderTraversal(root);
    printf("\n");

    struct TreeNode *binarySearchTree = convertToBinarySearchTree(root);

    printf("In-Order Traversal of Converted Binary Search Tree:\n");
    inOrderTraversal(binarySearchTree);
    printf("\n");

    int numVertices = 7; // Assuming there are 8 vertices (0 to 7)
    struct Graph *graph = createGraph(numVertices);

    convertTreeToGraph(binarySearchTree, graph->adjLists);

    int source = 4; // Source vertex for Dijkstra's algorithm
    dijkstra(graph, source);

    return 0;
}
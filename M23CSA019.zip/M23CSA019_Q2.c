#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* createNode(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

void inorder(struct Node* root, struct Node** sorted, int* idx) {
    if (root != NULL) {
        inorder(root->left, sorted, idx);
        sorted[*idx] = root;
        (*idx)++;
        inorder(root->right, sorted, idx);
    }
}

void updateValues(struct Node* root, struct Node** sorted, int* idx) {
    if (root != NULL) {
        updateValues(root->left, sorted, idx);
        root->data = sorted[*idx]->data;
        (*idx)++;
        updateValues(root->right, sorted, idx);
    }
}

void printInorder(struct Node* root) {
    if (root != NULL) {
        printInorder(root->left);
        printf("%d ", root->data);
        printInorder(root->right);
    }
}

int main() {
    // Create the source binary search tree
    struct Node* sourceRoot = createNode(25);
    sourceRoot->left = createNode(20);
    sourceRoot->right = createNode(36);
    sourceRoot->left->left = createNode(10);
    sourceRoot->left->right = createNode(22);
    sourceRoot->right->left = createNode(30);
    sourceRoot->right->right = createNode(40);
    sourceRoot->left->left->left = createNode(5);
    sourceRoot->left->left->right = createNode(12);
    sourceRoot->right->left->left = createNode(28);
    sourceRoot->right->right->right = createNode(64);

    // Create the target binary search tree (initially a copy of the source BST)
    struct Node* targetRoot = createNode(25);
    targetRoot->left = createNode(20);
    targetRoot->right = createNode(36);
    targetRoot->left->left = createNode(10);
    targetRoot->left->right = createNode(22);
    targetRoot->right->left = createNode(30);
    targetRoot->right->right = createNode(40);
    targetRoot->left->left->left = createNode(5);
    targetRoot->left->left->right = createNode(12);
    targetRoot->right->left->left = createNode(28);
    targetRoot->right->right->right = createNode(64);

    // Step 1: Perform an in-order traversal of the source BST
    int numNodes = 11;
    struct Node* sortedNodes[numNodes];
    int index = 0;
    inorder(sourceRoot, sortedNodes, &index);

    // Step 2: Traverse the target BST in-order and update values with values from the sorted list
    index = 0;
    updateValues(targetRoot, sortedNodes, &index);

    // Verify the result by printing the in-order traversal of the target BST
    printf("In-order traversal of the target BST after conversion:\n");
    printInorder(targetRoot);
    printf("\n");

    // Free allocated memory
    free(sourceRoot);
    free(targetRoot);

    return 0;
}
